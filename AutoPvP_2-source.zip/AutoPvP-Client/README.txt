AUTO PvP CLIENT (Fabric, Minecraft 26.3)
Build: JDK 25 + Gradle wrapper 9.5.1 (official Fabric template se gradle/ folder, gradlew, gradlew.bat copy karo)
       ./gradlew build  ->  build/libs/AutoPvP_1.jar -> mods folder
Keys:  Z = GUI (settings + start/stop)   X = quick start/stop
Setup: inventory mein jo bhi ho (mace, wind charge, crystals, obsidian, sword, axe, splash pots, gapple, totem) -
       bot khud hotbar mein laata hai aur combo mein use karta hai.
