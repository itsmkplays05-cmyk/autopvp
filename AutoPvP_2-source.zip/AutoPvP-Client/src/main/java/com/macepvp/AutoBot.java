package com.macepvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.function.Predicate;

/** AUTO PvP brain: scans the inventory and combines mace / wind charge / crystals / sword / axe / pots / food / totem. */
public class AutoBot {
    public static boolean running = false;
    public static String status = "Idle";

    private static int swapCd, healCd, hitCd, placeCd, pearlCd, windCd, stage, stageTicks, strafeTick;
    private static boolean eating;
    private static double peakY;

    // ================= start / stop =================
    public static void start(Minecraft mc) {
        running = true; stage = 0; eating = false; status = "Auto PvP ON";
        if (Cfg.chat && mc.player != null) mc.player.sendSystemMessage(Component.literal("§6[AutoPvP] §aStarted"));
    }

    public static void stop(Minecraft mc) {
        running = false; status = "Stopped"; release(mc);
        if (Cfg.chat && mc.player != null) mc.player.sendSystemMessage(Component.literal("§6[AutoPvP] §cStopped"));
    }

    // ================= main tick =================
    public static void tick(Minecraft mc) {
        if (!running) return;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) { running = false; return; }
        if (!p.isAlive()) { stop(mc); status = "Tum mar gaye"; return; }
        if (mc.screen != null) { release(mc); return; }

        if (swapCd > 0) swapCd--; if (healCd > 0) healCd--; if (hitCd > 0) hitCd--;
        if (placeCd > 0) placeCd--; if (pearlCd > 0) pearlCd--; if (windCd > 0) windCd--;
        mc.options.keyJump.setDown(false);

        boolean ground = p.onGround();
        if (ground) peakY = p.getY(); else peakY = Math.max(peakY, p.getY());
        double fall = peakY - p.getY();

        Player target = findTarget(mc, p);
        if (target == null) { status = "Target nahi mila"; release(mc); return; }
        if (!target.isAlive()) {
            if (Cfg.stopOnKill) { stop(mc); status = "Target haar gaya - WIN!"; }
            return;
        }
        float hp = p.getHealth() + p.getAbsorptionAmount();
        double dist = p.distanceTo(target);

        // ---------- SURVIVAL ----------
        if (Cfg.autoTotem && totem(mc, p)) return;

        if (Cfg.autoHeal && healCd == 0 && hp <= Cfg.healHp) {
            int s = get(mc, p, st -> splashHas(st, MobEffects.INSTANT_HEALTH));
            if (s >= 0) { throwDown(mc, p, s); status = "Healing potion"; return; }
        }

        if (Cfg.autoEat) {
            if (eating && hp >= Cfg.eatHp + 6) { mc.options.keyUse.setDown(false); eating = false; }
            if (hp <= Cfg.eatHp) {
                int s = get(mc, p, st -> st.is(Items.ENCHANTED_GOLDEN_APPLE) || st.is(Items.GOLDEN_APPLE)
                        || (p.getFoodData().needsFood() && st.has(DataComponents.FOOD)));
                if (s >= 0) {
                    p.getInventory().setSelectedSlot(s);
                    mc.options.keyUse.setDown(true);
                    move(mc, false, false, false, false, false);
                    eating = true; status = "Khana kha raha hai"; return;
                }
            }
            if (eating) { mc.options.keyUse.setDown(false); eating = false; }
        }

        if (Cfg.autoBuff && healCd == 0 && hp > Cfg.healHp && dist > 6) {
            int s;
            if (!p.hasEffect(MobEffects.STRENGTH) && (s = get(mc, p, st -> splashHas(st, MobEffects.STRENGTH))) >= 0) { throwDown(mc, p, s); status = "Strength"; return; }
            if (!p.hasEffect(MobEffects.SPEED) && (s = get(mc, p, st -> splashHas(st, MobEffects.SPEED))) >= 0) { throwDown(mc, p, s); status = "Speed"; return; }
            if (!p.hasEffect(MobEffects.FIRE_RESISTANCE) && (s = get(mc, p, st -> splashHas(st, MobEffects.FIRE_RESISTANCE))) >= 0) { throwDown(mc, p, s); status = "Fire res"; return; }
        }

        // ---------- OFFENSE ----------
        if (stage == 0) {
            if (Cfg.usePearl && dist > Cfg.pearlMin && pearlCd == 0) {
                int s = get(mc, p, st -> st.is(Items.ENDER_PEARL));
                if (s >= 0) {
                    aim(p, target);
                    p.setXRot(p.getXRot() - (float) Math.min(25.0, dist * 0.6));
                    p.getInventory().setSelectedSlot(s);
                    mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                    pearlCd = 100; status = "Ender pearl"; return;
                }
            }
            if (Cfg.useCrystal && crystals(mc, p, target, dist, hp)) return;
        }
        if (Cfg.useMace && maceCombo(mc, p, target, dist, fall, ground)) return;
        if (Cfg.useMelee || stage == 0) melee(mc, p, target, dist, fall, ground);
    }

    // ================= MACE COMBO =================
    private static boolean maceCombo(Minecraft mc, LocalPlayer p, Player t, double dist, double fall, boolean ground) {
        int mace = get(mc, p, st -> st.is(Items.MACE));
        if (mace < 0) { stage = 0; return false; }
        boolean ready = p.getAttackStrengthScale(0.5f) >= 0.95f;

        if (stage == 0) {
            int wind = Cfg.useWind ? get(mc, p, st -> st.is(Items.WIND_CHARGE)) : -1;
            if (wind >= 0 && ground && windCd == 0 && dist <= Cfg.windMaxDist) {
                aim(p, t); move(mc, true, false, false, false, true);
                mc.options.keyJump.setDown(true);
                stage = 1; stageTicks = 0; status = "Mace combo: jump";
                return true;
            }
            return false; // normal melee with mace/sword
        }
        aim(p, t);
        move(mc, true, false, false, false, true);
        stageTicks++;
        if (stage == 1) {
            int wind = get(mc, p, st -> st.is(Items.WIND_CHARGE));
            if (!ground && p.getDeltaMovement().y > 0.1 && wind >= 0) {
                p.setXRot(90f);
                p.getInventory().setSelectedSlot(wind);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                stage = 2; stageTicks = 0; status = "Mace combo: wind launch";
            } else if (stageTicks > 12) { stage = 0; windCd = 20; }
            return true;
        }
        // stage 2: in the air, smash when falling near target
        status = "Mace smash!";
        if (dist <= Cfg.attackRange + 0.4 && fall >= Cfg.maceFall && ready) {
            p.getInventory().setSelectedSlot(mace);
            mc.gameMode.attack(p, t);
            p.swing(InteractionHand.MAIN_HAND);
            stage = 0; windCd = 40;
        } else if (ground && stageTicks > 5 || stageTicks > 80) { stage = 0; windCd = 30; }
        else if (!ground && p.getDeltaMovement().y < 0) p.getInventory().setSelectedSlot(mace);
        return true;
    }

    // ================= CRYSTAL PvP =================
    private static boolean crystals(Minecraft mc, LocalPlayer p, Player t, double dist, float hp) {
        if (hp < Cfg.crystalMinHp || dist > 9) return false;
        int crystal = get(mc, p, st -> st.is(Items.END_CRYSTAL));
        if (crystal < 0) return false;
        aim(p, t);
        double keep = Cfg.keepDist;
        move(mc, dist > keep, dist < 3.0, false, false, dist > keep + 2);
        strafe(mc, dist);

        // 1) explode an existing crystal near the target
        EndCrystal best = null; double bd = 99;
        for (Entity e : mc.level.getEntities(null, t.getBoundingBox().inflate(4.0))) {
            if (e instanceof EndCrystal c) {
                double d = p.distanceTo(c);
                if (d <= Cfg.crystalRange && d < bd) { best = c; bd = d; }
            }
        }
        if (best != null) {
            status = "Crystal: explode";
            if (hitCd == 0) {
                mc.gameMode.attack(p, best); p.swing(InteractionHand.MAIN_HAND);
                hitCd = (int) Cfg.crystalDelay;
            }
            return true;
        }
        // 2) place a crystal on obsidian/bedrock near the target
        BlockPos feet = t.blockPosition();
        BlockPos base = null; double bestD = 99;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = -1; dy <= 0; dy++) {
            BlockPos pos = feet.offset(dx, dy, dz);
            var st = mc.level.getBlockState(pos);
            if (!(st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK))) continue;
            if (!mc.level.getBlockState(pos.above()).isAir() || !mc.level.getBlockState(pos.above(2)).isAir()) continue;
            if (!mc.level.getEntities(null, new AABB(pos.above())).isEmpty()) continue;
            if (p.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > Cfg.crystalRange) continue;
            double d = Vec3.atCenterOf(pos).distanceTo(t.position());
            if (d < bestD) { bestD = d; base = pos; }
        }
        if (base != null) {
            status = "Crystal: place";
            if (placeCd == 0) {
                p.getInventory().setSelectedSlot(crystal);
                mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                        new BlockHitResult(Vec3.atCenterOf(base).add(0, 0.5, 0), Direction.UP, base, false));
                p.swing(InteractionHand.MAIN_HAND);
                placeCd = Math.max(1, (int) Cfg.crystalDelay);
            }
            return true;
        }
        // 3) no base: place obsidian next to the target
        if (Cfg.placeObsidian) {
            int obs = get(mc, p, st -> st.is(Items.OBSIDIAN));
            if (obs >= 0) {
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    BlockPos place = feet.offset(dx, 0, dz), floor = place.below();
                    if (!mc.level.getBlockState(place).isAir()) continue;
                    if (mc.level.getBlockState(floor).isAir()) continue;
                    if (!mc.level.getBlockState(place.above()).isAir() || !mc.level.getBlockState(place.above(2)).isAir()) continue;
                    if (p.getEyePosition().distanceTo(Vec3.atCenterOf(floor)) > Cfg.crystalRange) continue;
                    status = "Obsidian place";
                    if (placeCd == 0) {
                        p.getInventory().setSelectedSlot(obs);
                        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                                new BlockHitResult(Vec3.atCenterOf(floor).add(0, 0.5, 0), Direction.UP, floor, false));
                        p.swing(InteractionHand.MAIN_HAND);
                        placeCd = 2;
                    }
                    return true;
                }
            }
        }
        return false;
    }

    // ================= MELEE =================
    private static void melee(Minecraft mc, LocalPlayer p, Player t, double dist, double fall, boolean ground) {
        int axe = get(mc, p, st -> st.is(ItemTags.AXES));
        int sword = get(mc, p, st -> st.is(ItemTags.SWORDS));
        int mace = Cfg.useMace ? get(mc, p, st -> st.is(Items.MACE)) : -1;
        int w;
        if (Cfg.shieldBreak && t.isBlocking() && axe >= 0) w = axe;
        else if (sword >= 0) w = sword;
        else if (axe >= 0) w = axe;
        else w = mace;
        if (w >= 0) p.getInventory().setSelectedSlot(w);

        aim(p, t);
        move(mc, dist > 2.0, false, false, false, true);
        strafe(mc, dist);
        status = "Melee";
        boolean ready = p.getAttackStrengthScale(0.5f) >= 0.95f;
        if (dist <= Cfg.attackRange && ready) {
            if (Cfg.critJump && ground) { mc.options.keyJump.setDown(true); return; }
            if (Cfg.critJump && p.getDeltaMovement().y >= 0) return;
            mc.gameMode.attack(p, t);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    // ================= helpers =================
    private static boolean totem(Minecraft mc, LocalPlayer p) {
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING) || swapCd > 0) return false;
        for (int i = 9; i <= 44; i++) {
            if (p.inventoryMenu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) {
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, i, 40, ClickType.SWAP, p);
                swapCd = 3; status = "Totem offhand mein"; return true;
            }
        }
        return false;
    }

    private static void throwDown(Minecraft mc, LocalPlayer p, int slot) {
        p.setXRot(90f);
        p.getInventory().setSelectedSlot(slot);
        mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
        healCd = 6;
    }

    private static boolean splashHas(ItemStack st, Holder<MobEffect> eff) {
        if (!st.is(Items.SPLASH_POTION)) return false;
        PotionContents pc = st.get(DataComponents.POTION_CONTENTS);
        if (pc == null) return false;
        for (MobEffectInstance e : pc.getAllEffects()) if (e.getEffect().equals(eff)) return true;
        return false;
    }

    /** Hotbar slot holding a matching item; if it is only in the main inventory, swap it into the hotbar. */
    private static int get(Minecraft mc, LocalPlayer p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) if (f.test(p.getInventory().getItem(i))) return i;
        if (Cfg.organise && swapCd == 0) {
            for (int s = 9; s <= 35; s++) {
                if (f.test(p.inventoryMenu.getSlot(s).getItem())) {
                    mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, s, lowestHotbar(p), ClickType.SWAP, p);
                    swapCd = 3;
                    break;
                }
            }
        }
        return -1;
    }

    private static int lowestHotbar(LocalPlayer p) {
        int best = 8, bv = Integer.MAX_VALUE;
        for (int i = 8; i >= 0; i--) {
            int v = value(p.getInventory().getItem(i));
            if (v < bv) { bv = v; best = i; }
        }
        return best;
    }

    private static int value(ItemStack s) {
        if (s.isEmpty()) return -1;
        if (s.is(Items.MACE)) return 100;
        if (s.is(ItemTags.SWORDS)) return 90;
        if (s.is(ItemTags.AXES)) return 80;
        if (s.is(Items.WIND_CHARGE) || s.is(Items.END_CRYSTAL)) return 70;
        if (splashHas(s, MobEffects.INSTANT_HEALTH)) return 65;
        if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE)) return 60;
        if (s.is(Items.OBSIDIAN)) return 50;
        if (s.is(Items.ENDER_PEARL)) return 40;
        if (s.is(Items.SPLASH_POTION)) return 30;
        return 0;
    }

    private static Player findTarget(Minecraft mc, LocalPlayer p) {
        String n = Cfg.targetName;
        Player best = null; double bd = Cfg.searchRange;
        for (Player pl : mc.level.players()) {
            if (pl == p || pl.isSpectator()) continue;
            if (!n.isEmpty()) {
                if (pl.getName().getString().equalsIgnoreCase(n)) return pl;
            } else {
                double d = p.distanceTo(pl);
                if (d < bd) { bd = d; best = pl; }
            }
        }
        return best;
    }

    private static void aim(LocalPlayer p, Player t) {
        Vec3 d = t.getBoundingBox().getCenter().subtract(p.getEyePosition());
        p.setYRot((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        p.setXRot((float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
    }

    private static void strafe(Minecraft mc, double dist) {
        if (!Cfg.strafe || dist > 7) return;
        strafeTick++;
        boolean left = (strafeTick / 25) % 2 == 0;
        mc.options.keyLeft.setDown(left);
        mc.options.keyRight.setDown(!left);
    }

    private static void move(Minecraft mc, boolean fwd, boolean back, boolean l, boolean r, boolean sprint) {
        mc.options.keyUp.setDown(fwd);
        mc.options.keyDown.setDown(back);
        mc.options.keyLeft.setDown(l);
        mc.options.keyRight.setDown(r);
        mc.options.keySprint.setDown(sprint);
    }

    private static void release(Minecraft mc) {
        if (mc.options == null) return;
        move(mc, false, false, false, false, false);
        mc.options.keyJump.setDown(false);
        mc.options.keyUse.setDown(false);
        eating = false; stage = 0;
    }
}
