package com.macepvp;

/** All settings (edited from the GUI). */
public class Cfg {
    // target
    public static String targetName = "";
    public static double searchRange = 48;
    public static boolean stopOnKill = true, chat = true;
    // combat
    public static boolean useMace = true, useWind = true, useCrystal = true, placeObsidian = true,
            useMelee = true, shieldBreak = true, critJump = false, strafe = true, usePearl = false;
    // survival
    public static boolean autoTotem = true, autoHeal = true, autoBuff = true, autoEat = true, organise = true;
    public static double healHp = 10, eatHp = 12, crystalMinHp = 8;
    // tuning
    public static double attackRange = 3.0, crystalRange = 4.5, crystalDelay = 2, keepDist = 4.5,
            windMaxDist = 8, pearlMin = 20, maceFall = 1.5;
}
