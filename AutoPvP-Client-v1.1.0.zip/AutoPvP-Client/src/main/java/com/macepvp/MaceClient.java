package com.macepvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class MaceClient implements ClientModInitializer {
    private static KeyMapping openKey, toggleKey;
    private static boolean greeted = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("macepvp", "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.macepvp.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, cat));
        toggleKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.macepvp.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_X, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!greeted && mc.player != null) {
                greeted = true;
                mc.player.sendSystemMessage(net.minecraft.network.chat.Component.literal("§6[AutoPvP] §aLoaded! §7Z = menu, X = quick start/stop"));
            }
            while (openKey.consumeClick()) {
                if (mc.screen == null && mc.player != null) mc.setScreenAndShow(new MainScreen());
            }
            while (toggleKey.consumeClick()) {
                if (mc.screen == null && mc.player != null) {
                    if (AutoBot.running) AutoBot.stop(mc); else AutoBot.start(mc);
                }
            }
            AutoBot.tick(mc);
        });
    }
}
