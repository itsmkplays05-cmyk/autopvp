package com.macepvp;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

public class MainScreen extends Screen {
    private static final String[] TABS = {"Target", "Combat", "Survival", "Tuning"};
    private static int tab = 0;
    private Button startBtn;
    private StringWidget statusLine;
    private EditBox nameBox;

    public MainScreen() { super(Component.literal("Auto PvP")); }

    @Override
    protected void init() {
        int cx = width / 2;
        addRenderableWidget(new StringWidget(cx - 200, 8, 400, 12,
                Component.literal("§6§l⚔ AUTO PvP CLIENT §7| inventory scan • best combo"), font).alignCenter());

        nameBox = new EditBox(font, cx - 205, 24, 410, 20, Component.literal("Target"));
        nameBox.setHint(Component.literal("§7Enemy ka naam (khali = sabse paas wala player)"));
        nameBox.setMaxLength(16);
        nameBox.setValue(Cfg.targetName);
        nameBox.setResponder(s -> Cfg.targetName = s.trim());
        addRenderableWidget(nameBox);

        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(
                    Component.literal((tab == i ? "§e§l" : "§7") + TABS[i]),
                    b -> { tab = idx; rebuildWidgets(); })
                    .bounds(cx - 205 + i * 104, 50, 98, 20).build());
        }

        switch (tab) {
            case 0 -> {
                cyc(0, 0, "Search range", new double[]{16, 24, 32, 48, 64, 100}, () -> Cfg.searchRange, v -> Cfg.searchRange = v, " blocks");
                tog(1, 0, "Stop when target dies", () -> Cfg.stopOnKill, v -> Cfg.stopOnKill = v);
                tog(0, 1, "Chat messages", () -> Cfg.chat, v -> Cfg.chat = v);
                addRenderableWidget(new StringWidget(cx - 205, 78 + 3 * 22, 410, 12,
                        Component.literal("§7Quick start/stop: X key • GUI: Z key"), font).alignCenter());
                addRenderableWidget(new StringWidget(cx - 205, 78 + 4 * 22, 410, 12,
                        Component.literal("§7Auto mode inventory dekhke mace/wind/crystal/sword/axe/pots sab use karega"), font).alignCenter());
            }
            case 1 -> {
                tog(0, 0, "Mace Combo", () -> Cfg.useMace, v -> Cfg.useMace = v);
                tog(1, 0, "Wind Charge Launch", () -> Cfg.useWind, v -> Cfg.useWind = v);
                tog(0, 1, "Crystal PvP", () -> Cfg.useCrystal, v -> Cfg.useCrystal = v);
                tog(1, 1, "Place Obsidian", () -> Cfg.placeObsidian, v -> Cfg.placeObsidian = v);
                tog(0, 2, "Melee (Sword/Axe)", () -> Cfg.useMelee, v -> Cfg.useMelee = v);
                tog(1, 2, "Axe Shield Break", () -> Cfg.shieldBreak, v -> Cfg.shieldBreak = v);
                tog(0, 3, "Crit Jumps", () -> Cfg.critJump, v -> Cfg.critJump = v);
                tog(1, 3, "Strafe", () -> Cfg.strafe, v -> Cfg.strafe = v);
                tog(0, 4, "Ender Pearl Approach", () -> Cfg.usePearl, v -> Cfg.usePearl = v);
            }
            case 2 -> {
                tog(0, 0, "Auto Totem", () -> Cfg.autoTotem, v -> Cfg.autoTotem = v);
                tog(1, 0, "Auto Heal Potion", () -> Cfg.autoHeal, v -> Cfg.autoHeal = v);
                cyc(1, 1, "Heal below", new double[]{4, 6, 8, 10, 12, 14, 16}, () -> Cfg.healHp, v -> Cfg.healHp = v, " HP");
                tog(0, 1, "Auto Buff Potions", () -> Cfg.autoBuff, v -> Cfg.autoBuff = v);
                tog(0, 2, "Auto Eat / Gapple", () -> Cfg.autoEat, v -> Cfg.autoEat = v);
                cyc(1, 2, "Eat below", new double[]{6, 8, 10, 12, 14, 16}, () -> Cfg.eatHp, v -> Cfg.eatHp = v, " HP");
                tog(0, 3, "Hotbar Organise", () -> Cfg.organise, v -> Cfg.organise = v);
                cyc(1, 3, "Crystal min HP", new double[]{0, 4, 6, 8, 10, 12}, () -> Cfg.crystalMinHp, v -> Cfg.crystalMinHp = v, " HP");
            }
            default -> {
                cyc(0, 0, "Attack range", new double[]{2.5, 3.0, 3.5, 4.0}, () -> Cfg.attackRange, v -> Cfg.attackRange = v, "");
                cyc(1, 0, "Crystal range", new double[]{3.5, 4.0, 4.5, 5.0}, () -> Cfg.crystalRange, v -> Cfg.crystalRange = v, "");
                cyc(0, 1, "Crystal delay", new double[]{0, 1, 2, 3, 4, 6, 8}, () -> Cfg.crystalDelay, v -> Cfg.crystalDelay = v, " ticks");
                cyc(1, 1, "Keep distance", new double[]{3.5, 4, 4.5, 5, 6}, () -> Cfg.keepDist, v -> Cfg.keepDist = v, "");
                cyc(0, 2, "Wind combo max dist", new double[]{5, 6, 8, 10, 12}, () -> Cfg.windMaxDist, v -> Cfg.windMaxDist = v, "");
                cyc(1, 2, "Pearl min dist", new double[]{10, 15, 20, 30}, () -> Cfg.pearlMin, v -> Cfg.pearlMin = v, "");
                cyc(0, 3, "Mace min fall", new double[]{1.5, 2, 3, 4}, () -> Cfg.maceFall, v -> Cfg.maceFall = v, " blocks");
            }
        }

        startBtn = Button.builder(startLabel(), b -> {
            if (AutoBot.running) AutoBot.stop(minecraft);
            else { AutoBot.start(minecraft); minecraft.setScreenAndShow(null); }
        }).bounds(cx - 205, 196, 300, 22).build();
        addRenderableWidget(startBtn);
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(cx + 100, 196, 105, 22).build());
        statusLine = addRenderableWidget(new StringWidget(cx - 205, 224, 410, 12,
                Component.literal("Status: " + AutoBot.status), font).alignCenter());
    }

    private Component startLabel() {
        return Component.literal(AutoBot.running ? "§c■ STOP AUTO PvP" : "§a▶ START AUTO PvP");
    }

    private static String fmt(double v) { return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(v); }

    private void tog(int col, int row, String name, BooleanSupplier g, Consumer<Boolean> s) {
        addRenderableWidget(Button.builder(
                Component.literal(name + ": " + (g.getAsBoolean() ? "§aON" : "§cOFF")),
                b -> {
                    s.accept(!g.getAsBoolean());
                    b.setMessage(Component.literal(name + ": " + (g.getAsBoolean() ? "§aON" : "§cOFF")));
                }).bounds(width / 2 - 205 + col * 210, 78 + row * 22, 200, 20).build());
    }

    private void cyc(int col, int row, String name, double[] vals, DoubleSupplier g, DoubleConsumer s, String unit) {
        addRenderableWidget(Button.builder(
                Component.literal(name + ": §e" + fmt(g.getAsDouble()) + unit),
                b -> {
                    int cur = 0;
                    for (int i = 0; i < vals.length; i++) if (vals[i] == g.getAsDouble()) cur = i;
                    s.accept(vals[(cur + 1) % vals.length]);
                    b.setMessage(Component.literal(name + ": §e" + fmt(g.getAsDouble()) + unit));
                }).bounds(width / 2 - 205 + col * 210, 78 + row * 22, 200, 20).build());
    }

    @Override
    public void tick() {
        if (statusLine != null) statusLine.setMessage(Component.literal("§7Status: §f" + AutoBot.status));
        if (startBtn != null) startBtn.setMessage(startLabel());
    }

    @Override
    public void onClose() { minecraft.setScreenAndShow(null); }
}
